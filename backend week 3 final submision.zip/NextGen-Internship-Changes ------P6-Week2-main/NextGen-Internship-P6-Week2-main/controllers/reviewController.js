import mongoose from 'mongoose';
import Tour from "../models/Tour.js";
import Review from "../models/Review.js";

export const createReview = async (req, res) => {
  const { tourId } = req.params;

  // Validate tourId
  if (!mongoose.Types.ObjectId.isValid(tourId)) {
    return res.status(400).json({ success: false, message: 'Invalid tour ID' });
  }

  const newReview = new Review({ ...req.body });

  try {
    // Start a session for transaction
    const session = await mongoose.startSession();
    session.startTransaction();

    // Save the new review
    const savedReview = await newReview.save({ session });

    // Update the tour's reviews array
    const updatedTour = await Tour.findByIdAndUpdate(
      tourId,
      { $push: { reviews: savedReview._id } },
      { new: true, session } // Return the updated document
    );

    if (!updatedTour) {
      throw new Error('Tour not found');
    }

    // Commit the transaction
    await session.commitTransaction();
    session.endSession();

    res.status(200).json({
      success: true,
      message: 'Review submitted successfully',
      data: savedReview,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Failed to submit review',
      error: err.message,
    });
  }
};
