import User from '../models/User.js';

// Utility function for consistent responses
const sendResponse = (res, success, message, data = null, status = 200) => {
  res.status(status).json({ success, message, data });
};

// Create new user
export const createUser = async (req, res) => {
  try {
    const newUser = new User(req.body);
    const savedUser = await newUser.save();
    sendResponse(res, true, 'User created successfully', savedUser, 201);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to create user', null, 500);
  }
};

// Update user
export const updateUser = async (req, res) => {
  const { id } = req.params;
  try {
    const updatedUser = await User.findByIdAndUpdate(id, { $set: req.body }, { new: true });
    if (!updatedUser) return sendResponse(res, false, 'User not found', null, 404);
    sendResponse(res, true, 'User updated successfully', updatedUser);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to update user', null, 500);
  }
};

// Delete user
export const deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    const deletedUser = await User.findByIdAndDelete(id);
    if (!deletedUser) return sendResponse(res, false, 'User not found', null, 404);
    sendResponse(res, true, 'User deleted successfully');
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to delete user', null, 500);
  }
};

// Get single user
export const getSingleUser = async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findById(id);
    if (!user) return sendResponse(res, false, 'User not found', null, 404);
    sendResponse(res, true, 'User retrieved successfully', user);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve user', null, 500);
  }
};

// Get all users (with optional pagination)
export const getAllUser = async (req, res) => {
  const page = parseInt(req.query.page) || 0;
  const limit = parseInt(req.query.limit) || 10;
  try {
    const users = await User.find({})
      .skip(page * limit)
      .limit(limit);
    const totalUsers = await User.countDocuments();
    sendResponse(res, true, 'Users retrieved successfully', { users, total: totalUsers });
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve users', null, 500);
  }
};
