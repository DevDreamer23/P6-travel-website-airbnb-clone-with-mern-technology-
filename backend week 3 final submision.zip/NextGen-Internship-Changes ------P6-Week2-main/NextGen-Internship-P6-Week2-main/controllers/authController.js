import User from "../models/User.js";
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// Utility for token creation
const createToken = (userId, role) => {
  return jwt.sign({ id: userId, role }, process.env.JWT_SECRET_KEY, { expiresIn: '15d' });
};

// User Registration
export const register = async (req, res) => {
  try {
    const { username, email, password, photo } = req.body;

    // Check if email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Email already in use' });
    }

    // Hashing password
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);

    const newUser = new User({ username, email, password: hash, photo });
    await newUser.save();

    res.status(201).json({ success: true, message: 'User registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to register user. Try again later' });
  }
};

// User Login
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const { password: _, role, ...userData } = user._doc;
    const token = createToken(user._id, role);

    res
      .cookie('accessToken', token, { httpOnly: true, secure: true, maxAge: 15 * 24 * 60 * 60 * 1000 }) // Secure cookie
      .status(200)
      .json({ success: true, token, user: userData, role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Login failed. Try again later' });
  }
};
