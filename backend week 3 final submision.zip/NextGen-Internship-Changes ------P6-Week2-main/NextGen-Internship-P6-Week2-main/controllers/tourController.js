import Tour from '../models/Tour.js';

// Utility function for consistent responses
const sendResponse = (res, success, message, data = null, status = 200) => {
  res.status(status).json({ success, message, data });
};

// Create new tour
export const createTour = async (req, res) => {
  try {
    const newTour = new Tour(req.body);
    const savedTour = await newTour.save();
    sendResponse(res, true, 'Tour created successfully', savedTour, 201);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to create tour', null, 500);
  }
};

// Update tour
export const updateTour = async (req, res) => {
  const { id } = req.params;
  try {
    const updatedTour = await Tour.findByIdAndUpdate(id, { $set: req.body }, { new: true });
    if (!updatedTour) return sendResponse(res, false, 'Tour not found', null, 404);
    sendResponse(res, true, 'Tour updated successfully', updatedTour);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to update tour', null, 500);
  }
};

// Delete tour
export const deleteTour = async (req, res) => {
  const { id } = req.params;
  try {
    const deletedTour = await Tour.findByIdAndDelete(id);
    if (!deletedTour) return sendResponse(res, false, 'Tour not found', null, 404);
    sendResponse(res, true, 'Tour deleted successfully');
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to delete tour', null, 500);
  }
};

// Get single tour
export const getSingleTour = async (req, res) => {
  const { id } = req.params;
  try {
    const tour = await Tour.findById(id).populate('reviews');
    if (!tour) return sendResponse(res, false, 'Tour not found', null, 404);
    sendResponse(res, true, 'Tour retrieved successfully', tour);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve tour', null, 500);
  }
};

// Get all tours with pagination
export const getAllTour = async (req, res) => {
  const page = parseInt(req.query.page) || 0;
  const limit = 8;
  try {
    const tours = await Tour.find({})
      .populate('reviews')
      .skip(page * limit)
      .limit(limit);
    sendResponse(res, true, 'Tours retrieved successfully', tours);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve tours', null, 500);
  }
};

// Search tours
export const getTourBySearch = async (req, res) => {
  const { city, distance, maxGroupSize } = req.query;
  try {
    const query = {
      city: new RegExp(city, 'i'),
      distance: { $gte: parseInt(distance) || 0 },
      maxGroupSize: { $gte: parseInt(maxGroupSize) || 0 },
    };
    const tours = await Tour.find(query).populate('reviews');
    if (!tours.length) return sendResponse(res, false, 'No tours found', [], 404);
    sendResponse(res, true, 'Tours retrieved successfully', tours);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to search tours', null, 500);
  }
};

// Get featured tours
export const getFeaturedTour = async (req, res) => {
  try {
    const tours = await Tour.find({ featured: true }).populate('reviews').limit(8);
    if (!tours.length) return sendResponse(res, false, 'No featured tours found', [], 404);
    sendResponse(res, true, 'Featured tours retrieved successfully', tours);
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve featured tours', null, 500);
  }
};

// Get tour count
export const getTourCount = async (req, res) => {
  try {
    const tourCount = await Tour.estimatedDocumentCount();
    sendResponse(res, true, 'Tour count retrieved successfully', { count: tourCount });
  } catch (err) {
    console.error(err);
    sendResponse(res, false, 'Failed to retrieve tour count', null, 500);
  }
};
